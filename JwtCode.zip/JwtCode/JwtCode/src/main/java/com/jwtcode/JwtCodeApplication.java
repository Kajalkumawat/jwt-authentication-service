package com.jwtcode;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class JwtCodeApplication {

	public static void main(String[] args) {
		SpringApplication.run(JwtCodeApplication.class, args);
	}

}
