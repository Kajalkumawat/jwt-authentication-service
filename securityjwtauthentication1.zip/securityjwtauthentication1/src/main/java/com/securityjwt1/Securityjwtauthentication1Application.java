package com.securityjwt1;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Securityjwtauthentication1Application {

	public static void main(String[] args) {
		SpringApplication.run(Securityjwtauthentication1Application.class, args);
	}

}
