package com.securityjwt1;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Securityjwtauthentication1ApplicationTests {

	@Test
	void contextLoads() {
	}

}
